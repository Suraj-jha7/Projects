
var i=1;
var target=0;
var current=document.querySelector('.current');
var next=document.querySelector('.next');


function startCounter(){
    target=document.getElementById('text').value;
    console.log(target);

    var Interval=setInterval(function(){
        if(target==i)
        {
            clearInterval(Interval);
            return;
        }
    next.innerHTML=i;
    next.classList.add('animate');
    i++;
    
    
    setTimeout(function()
    { 
        current.innerHTML=next.innerHTML;
        next.classList.remove('animate');
        ;
    },500)
    

    
},1000)
}

